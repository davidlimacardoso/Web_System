<?php
//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!
/*if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}*/
		include("conexao.php");

		//Definindo fuso horário
		date_default_timezone_set('America/Sao_Paulo');
		
		
		$result_agenda = "SELECT * FROM tb_agenda";
		//PEGAR OS DADOS DO BANCO ATRAVÉS DA QUERY E ATRIBUIR À VARIÁVEL
		$result_agenda = mysqli_query($conn, $result_agenda);
				
		//CRIAR PAGINAÇÃO
		//----------------------------------------------------------------------------------------



		//LISTAR CADA LINHA DA ARRAY DO BD COM WHILE 
		echo	"<table class='table table-striped table-hover table-responsive-lg table-responsive-mg table-responsive-sm align-items-baseline'>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Código" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Registrado" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Prazo" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Descrição" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Estado" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>" . "</td>";
				
		while ($row_agenda = mysqli_fetch_assoc($result_agenda)){
			
			$id = $row_agenda['id'];//VARIÁVEL DEFINIR VALOR AO BOTÃO CONCLUIR
			$estado = $row_agenda['estado'];
			
			echo "<tr scope='row' class='text-center'>" . "<td class='tamanho-tabela'>". $row_agenda['id'] ."</td>".
				"<td>" . date('d/m/Y H:i', strtotime($row_agenda['dataAtual']))."</td>".
		 		"<td>" . date('d/m/Y', strtotime($row_agenda['dataCad']))."</td>".
		 		"<td>". $row_agenda['descricao'] ."</td>";
			
			$dataAtual = $row_agenda['dataAtual'];
			$dataCad = $row_agenda['dataCad'];
			
			//ESCONDER O BOTAO QUANDO CONCLUIDO
			if($row_agenda['estado'] == "CONCLUÍDO"){
				echo "<td class='text-success font-weight-bold'>". $row_agenda['estado'] ."</td>".
		 		"<td><form action='botaoExcluir.php' method='post'><button type='submit' class='btn bg-transparent' aria-label='Remover' name='btnExcluir' value='$id'><span class='glyphicon glyphicon-trash  h3 text-danger' aria-hidden='true'></span></button></form></td>"."</tr>";
			}
			else{
				if($dataAtual < $dataCad){
				echo "<td class='font-weight-bold'>". $row_agenda['estado'] ."</td>".
		 		"<td class='row float-right'><form action='agendaEstado.php' method='post'><button type='submit' class='btn bg-transparent' type='submit' name='btnConcluir' value='$id' aria-label='Concluir'><span class='glyphicon glyphicon-ok-circle  h2 text-success' aria-hidden='true'></span></button></form><form action='botaoExcluir.php' method='post'><button type='submit' class='btn bg-transparent' aria-label='Remover' name='btnExcluir' value='$id'><span class='glyphicon glyphicon-trash  h3 text-danger' aria-hidden='true'></span></button></form></td>"."</tr>";
			}
			
			
				else{
					echo "<td class='text-danger font-weight-bold'>". $row_agenda['estado'] ."</td>".
		 			"<td><form action='agendaEstado.php' method='post'><button type='submit' class='btn bg-transparent' type='submit' name='btnConcluir' value='$id' aria-label='Concluir'><span class='glyphicon glyphicon-ok-circle  h2 text-success' aria-hidden='true'></span></button></form></td>"."</tr>";
				}
			}
			
		}
		echo "</table>";
		
		
		?>