<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Acesso!</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.css">	
	<link rel="stylesheet" href="node_modules/glyphicons/css/bootstrap-glyphicons.min.css">
	<link rel="stylesheet" href="css/input.css">
</head> 

<body class="bg-info">

	<div class="container mt-5">
		<div class="">
			<h1 class="text-center pb-3">MyTarefas</h1>
        	<h2 class="text-center pb-3">Acesso ao Sistema</h2>
		</div>
		
           <form action="validarLogin.php" method="post">
               <div class="row mt-5">
                    <div class="form-group col-lg-4 col-md-4 col-sm-12 mx-auto iconInput">
                       <i class="glyphicon glyphicon-user h5 font-weight-bold"></i>       
                        <input type="text" class="placeholder form-control font-weight-bold shadow" name="txtUsuario" placeholder="USUÁRIO" class="form-control">
                    </div>
            	</div>

                <div class="row">
                    <div class="form-grou col-lg-4 col-md-4 col-sm-12 mx-auto iconInput">
                       <i class="glyphicon glyphicon-eye-close h5 font-weight-bold "></i> 
                        <input class="placeholder form-control font-weight-bold shadow" type="password" name="txtSenha" placeholder="SENHA" class="form-control">
                    </div>
                </div>

                <div class="row m-5">
                    <div class="form-group text-center col-lg-6 col-md-4 mx-auto">
                        <button class="btn btn-warning font-weight-bold shadow" type="submit" value="entrar">ENTRAR</button>
                    </div>
                </div> 	
			</form>
			
			 <?php
			if(isset($_SESSION['msgLogin'])){
				echo $_SESSION['msgLogin'];
				unset($_SESSION['msgLogin']);
			}
			?>
	</div>

</body>
</html>