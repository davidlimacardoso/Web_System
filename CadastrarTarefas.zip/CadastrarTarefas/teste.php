<? 

echo "<td  class='font-weight-bold'>". $row_agenda['estado'] ."</td>".
		 		"<td class='row float-right'><form action='agendaEstado.php' method='post'><button class='btn btn-primary' type='submit' name='btnConcluir' value='$id'><span class='material-icons'>Concluir</span></form></button><form action='botaoExcluir.php' method='post'><button class='btn btn-primary ml-3' type='submit' name='btnExcluir' value='$id'>Exluir</button></form></td>"."</tr>";
			}

?>