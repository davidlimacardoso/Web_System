<?php

session_start();

//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!


include ('conexao.php');

$login 	= $_POST["txtUsuario"];
$password 	= $_POST["txtSenha"];

$scrip = "SELECT * FROM TB_Usuario where user = ? AND senha = ?";
$sql = $conn->prepare($scrip);

//manda parametros (variaveis) para coluna da tabela
$sql->bind_param("ss", $login, $password);
$sql->execute();

$resultado = $sql->get_result();
$_SESSION[$login];
//Valida a seção
if(mysqli_num_rows($resultado)>0){
	$_SESSION['txtUsuario'] = $login;
	$_SESSION['txtSenha'] = $password;
	header("Location: cadastro.php");
	
}else{
	$_SESSION['msgLogin'] = "<div class='alert alert-warning w-25 m-auto text-center'> Insira 'Usuário' e 'Senha'! </div>";
	header("Location: index.php");
}
?>