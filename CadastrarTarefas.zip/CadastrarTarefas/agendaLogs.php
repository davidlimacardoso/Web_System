<?php
		include("conexao.php");
		
if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}

		//Definindo fuso horário
		date_default_timezone_set('America/Sao_Paulo');
		
		
		$result_agenda = "SELECT * FROM tb_logs";
		//PEGAR OS DADOS DO BANCO ATRAVÉS DA QUERY E ATRIBUIR À VARIÁVEL
		$result_agenda = mysqli_query($conn, $result_agenda);
				
		//LISTAR CADA LINHA DA ARRAY DO BD COM WHILE 
		echo	"<table class='table table-striped table-hover table-responsive-lg table-responsive-mg table-responsive-sm'>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Registrado" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Prazo" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Descrição" . "</td>" .
			"<td class='bg-dark text-white font-weight-bold text-center'>Mensagem" . "</td>";
				
		while ($row_agenda = mysqli_fetch_assoc($result_agenda)){
			
			$id = $row_agenda['id'];//VARIÁVEL DEFINIR VALOR AO BOTÃO CONCLUIR
			$estado = $row_agenda['estado'];
			
			echo "<tr scope='row' class='text-center'>" .
				"<td>" . date('d/m/Y H:i', strtotime($row_agenda['dataAtual']))."</td>".
		 		"<td>" . date('d/m/Y', strtotime($row_agenda['dataCad']))."</td>".
		 		"<td>". $row_agenda['descricao'] ."</td>".
		 		"<td>". $row_agenda['mensagem'] ."</td>";
				"</tr>";
			
		}
		echo "</table>";
		
		
		?>