<?php
session_start();

//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!
if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Criar tarefa</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.css">
	<link rel="stylesheet" href="node_modules/glyphicons/css/bootstrap-glyphicons.min.css">
	<script src="node_modules/jquery/dist/jquery.min.js"></script>
	<script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
	<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
</head>
<body class="bg-info">
  <h3 class="text-light container mt-2">Bem vindo <?php echo $_SESSION['txtUsuario'];  ?></h3>
	<div class="container mt-5 bg-light p-5 mb-4">		
		<h1 class="pb-3">Cadastre suas tarefas</h1>
		
			
          <div class="container align-items-baseline">
           <form action="validarAgenda.php" method="post">
               <div class="form-group row">
                    <div class="col-lg-3 col-md-4 col-sm-12 ">
                        <input type="date" name="txtPrazo"class="form-control" required>
                        <label>PRAZO</label> 
                    </div>
                    
                    <div class="col-lg-6 col-md-4 col-sm-12 ">
                        <input type="text" name="txtDescricao" class="form-control">
                        <label class="text-center">DESCRIÇÃO</label> 
                    </div>
                
                   <div class="col-lg-3 col-md-6 col-sm-6">
                        <button class="btn btn-warning" type="submit" value="cadastrar">CADASTRAR
                        </button> 
                        <?php include_once("modal.php") ?>                    
                    </div>
                    <?php 
				   			if(isset($_SESSION['msg'])){
							echo $_SESSION['msg'];
							unset($_SESSION['msg']);
		}
				   	?>
                </div>              
			</form>
			</div>
			<?php
				include("listar.php");
				include("footer.php");
		
			?>		
	</div>
 
</body>
</html>