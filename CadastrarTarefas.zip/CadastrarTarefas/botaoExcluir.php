<?php
include("conexao.php");

//recebe a ID da linha e armazena
$codAgenda = $_POST['btnExcluir'];


//INSERIR AS INFORMAÇÕES DA TB AGENDA PARA TB LOGS
$log = "INSERT INTO tb_logs (dataAtual, dataCad, descricao, estado, mensagem) SELECT dataAtual, dataCad, descricao, estado,  'Excluído com sucesso!' FROM tb_agenda WHERE id=" . $codAgenda;

$log = mysqli_query($conn, $log);

//REMOVER A LINHA DA TABELA AGENDA
$remover = "DELETE FROM tb_agenda WHERE  id =" . $codAgenda;

mysqli_query ($conn, $remover);
mysqli_error();
header("Location: cadastro.php");
	
?>