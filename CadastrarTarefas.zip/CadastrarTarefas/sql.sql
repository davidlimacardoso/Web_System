use dbagenda;

/*TABELA AGENDA*/
create table tb_agenda(
id int primary key auto_increment,
dataAtual timestamp null default current_timestamp,
dataCad date not null,
descricao varchar (250) not null,
estado varchar (100) not null
);
select * from tb_agenda;
INSERT INTO tb_agenda (dataAtual, dataCad, descricao, estado) values (dataAtual, dataCad, descricao, estado);
drop table tb_agenda;

/*TABELA LOGS*/
create table tb_logs(
id int primary key auto_increment,
dataAtual timestamp null default current_timestamp,
dataCad date not null,
descricao varchar (250) not null,
estado varchar (100) not null,
mensagem varchar (200) not null
);
select * from tb_logs;
INSERT INTO tb_logs (dataAtual, dataCad, descricao, estado) SELECT dataAtual, dataCad, descricao, estado FROM tb_agenda where id=54;
INSERT INTO tb_logs (dataAtual, dataCad, descricao, estado, mensagem) SELECT dataAtual, dataCad, descricao, estado,  'Alterado para Concluído!' FROM tb_agenda WHERE id=52;
Drop table tb_logs;

/*TABELA */
create table TB_Usuario(
id int primary key auto_increment,
user varchar (100) not null,
senha varchar (100) not null
);
insert into tb_usuario (user, senha) values ('admin', 123);
select * from tb_usuario;
