<?php

//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!
if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}

?>
    

   <footer class="page-footer font-small blue pt-4">

    <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">

      <!-- Grid row -->
      <div class="row">


      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Desenvolvido por:
      <a href="#"> David de Lima Cardoso</a>
    </div>
    <!-- Copyright -->

  </footer>