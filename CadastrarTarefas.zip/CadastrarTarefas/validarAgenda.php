<?php

session_start();

//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!
//---------------------------------------------------------------------------------------------
if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}
//---------------------------------------------------------------------------------------------

//Conexao com BD
//---------------------------------------------------------------------------------------------
include("conexao.php");
//---------------------------------------------------------------------------------------------

//definir fuso horário
//---------------------------------------------------------------------------------------------
date_default_timezone_set('America/Sao_Paulo'); 
//---------------------------------------------------------------------------------------------

//Receber os dados do formulário
//---------------------------------------------------------------------------------------------
$data = $_REQUEST['txtPrazo'];
$dataCal = date("d/m/Y", strtotime($data));
$descricao = $_REQUEST['txtDescricao'];
$dataAtual = date("d/m/Y");
//---------------------------------------------------------------------------------------------

//FORÇAR USUÁRIO A FAZER UMA DESCRIÇÃO
//---------------------------------------------------------------------------------------------
if(empty($descricao)){
	$_SESSION['msg'] = "<div class='alert alert-warning w-25 m-auto text-center'> Por favor faça pelo menos uma descrição! </div>";
	header("Location: cadastro.php");
	die();
}
//---------------------------------------------------------------------------------------------

//INSERIR ESTADO NO REGISTRO SITUAÇÃO
//---------------------------------------------------------------------------------------------
if($dataCal < $dataAtual){
	$situacao = "ATRASADO";
}else{
	$situacao = "ABERTO";
}
//-------------------------------------------------------------------------------------------------

//INSERINDO INFORMAÇÕES AO BANCO
//---------------------------------------------------------------------------------------------
$result = "INSERT INTO tb_agenda (dataCad, descricao, estado) VALUES ('$data' , '$descricao' , '$situacao')";
//INSERIR NO LOGS
$log = "INSERT INTO tb_logs (dataCad, descricao, estado, mensagem) VALUES ('$data' , '$descricao' , '$situacao' , 'Adicionado com sucesso!')";
$result = mysqli_query($conn, $result);
$log = mysqli_query($conn, $log);
//-----------------------------------------------------------------------------------------------

//VALIDAÇÕES NO CADASTRO
//-----------------------------------------------------------------------------------------------
if(mysqli_insert_id($conn)){
	$_SESSION['msg'] = "<div class='alert alert-success w-25 m-auto text-center'> Data cadastrada com sucesso </div>";
	header("Location: cadastro.php");
	}
	else{
	$_SESSION['msg'] = "<div class='alert alert-danger m-auto text-center''> Erro ao cadastradar a data </div>";
	header("Location: cadastro.php");
}
//-----------------------------------------------------------------------------------------------
?>