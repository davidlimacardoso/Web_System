<?php

//REDIRECIONAR À INDEX QUEM NAO ESTABELECE ACESSO!
if(!(isset($_SESSION['txtUsuario']))){
	header("Location: index.php");
	die();
}

?>


<button type="button" class="btn btn-success" aria-label="Logs" data-toggle="modal" data-target="#myModal">
	<span class="glyphicon glyphicon-th-list" aria-hidden="true"></span>
</button>   




<!-- The Modal -->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Histórico de Registro</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <?php
			include_once("agendaLogs.php");
		 ?>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
      </div>

    </div>
  </div>
</div>